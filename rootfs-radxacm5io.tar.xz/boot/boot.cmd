echo lin0 boot.scr official-style
setenv scriptaddr 0x00500000
setenv fdtfile rockchip/rk3588s-radxa-cm5-io.dtb
setenv bootargs console=tty0 root=LABEL=lin0root rootfstype=ext4 rootwait rw init=/bin/init
for d in 0 1; do
	if test -e mmc ${d}:2 /boot/extlinux/extlinux.conf; then
		echo lin0 root mmc ${d}:2
		sysboot mmc ${d}:2 any ${scriptaddr} /boot/extlinux/extlinux.conf && exit
	fi
	if test -e mmc ${d}:1 /extlinux/extlinux.conf; then
		echo lin0 fat mmc ${d}:1
		sysboot mmc ${d}:1 any ${scriptaddr} /extlinux/extlinux.conf && exit
	fi
done
echo lin0 FAIL
sleep 30
