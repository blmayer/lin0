savedcmd_usr/include/sound/fcp.h := sh ./scripts/headers_install.sh include/uapi/sound/fcp.h usr/include/sound/fcp.h
