savedcmd_usr/include/linux/dev_energymodel.h := sh ./scripts/headers_install.sh include/uapi/linux/dev_energymodel.h usr/include/linux/dev_energymodel.h
