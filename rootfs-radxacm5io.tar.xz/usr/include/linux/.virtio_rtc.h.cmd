savedcmd_usr/include/linux/virtio_rtc.h := sh ./scripts/headers_install.sh include/uapi/linux/virtio_rtc.h usr/include/linux/virtio_rtc.h
